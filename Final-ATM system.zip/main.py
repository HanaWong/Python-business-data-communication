passwordDict = {}
with open('login.txt', 'r') as f:
  for line in f:
    userName, password = line.split(',')
    passwordDict[userName.lower()] = password.rstrip()

def withdraw(userName):
  checking, saving = None, None
  userFile = userName + '.txt'
  with open(userFile, 'r') as f:
    lines = f.readlines()
    checking, saving = lines[-1].split(',')
    checking = int(checking)
    saving = int(saving)
  option = ''
  while option not in ['1', '2']:
    option = input('\nYour checking balance is: {}. Your saving balance is: {}\nWhich account do you want to withdraw from?\n1.Checking account\n2.Saving account\n'.format(checking, saving))
  
  amount = int(input('\nPlease enter the amount you would like to withdraw: '))
  if option == '1':
    if not 0 <= amount <= checking:
      print('The amount you entered is not valid!')
      return False
    else:
      checking -= amount
  else:
    if not 0 <= amount <= saving:
      print('The amount you entered is not valid!')
      return False
    else:
      saving -= amount
  
  print('\nYour checking balance is: {}. Your saving balance is: {}'.format(checking, saving))
  with open(userFile, 'a') as f:
    f.write(str(checking)+','+str(saving))
    f.write('\n')
  
  return True

def deposit(userName):
  checking, saving = None, None
  userFile = userName + '.txt'
  with open(userFile, 'r') as f:
    lines = f.readlines()
    checking, saving = lines[-1].split(',')
    checking = int(checking)
    saving = int(saving)
  option = ''
  while option not in ['1', '2']:
    option = input('\nYour checking balance is: {}. Your saving balance is: {}\nWhich account do you want to deposit into?\n1.Checking account\n2.Saving account\n'.format(checking, saving))
  
  amount = int(input('\nPlease enter the amount you would like to deposit: '))
  if option == '1':
    if not 0 <= amount:
      print('The amount you entered is not valid!')
      return False
    else:
      checking += amount
  else:
    if not 0 <= amount:
      print('The amount you entered is not valid!')
      return False
    else:
      saving += amount
  
  print('\nYour checking balance is: {}. Your saving balance is: {}'.format(checking, saving))
  with open(userFile, 'a') as f:
    f.write(str(checking)+','+str(saving))
    f.write('\n')
  
  return True

def receipt(userName):
  checking, saving = None, None
  userFile = userName + '.txt'
  with open(userFile, 'r') as f:
    lines = f.readlines()
    checking, saving = lines[-1].split(',')
    checking = int(checking)
    saving = int(saving)

  print('\n{}\'s receipt:'.format(userName))
  lwid= max(len('Checking'), len(str(checking)))
  print('Checking' + ' '*(lwid - len('Checking')) + '\t' + 'Savings')
  print(str(checking) + ' '*(lwid - len(str(checking))) +'\t'+str(saving))
  
  with open('receipt.txt', 'w') as f:
    f.write('{}\'s receipt\n'.format(userName))
    f.write('Checking,Savings\n')
    f.write(str(checking)+','+str(saving))

def main_menu(userName):
  while True:
    choice = ''
    while choice not in ['1', '2', '3']:
      choice = input("\nWhat would you like to do?\n1. Withdraw\n2. Deposit\n3. Log out\n")
    if choice == '1':
      withdraw(userName)

    elif choice == '2':
      deposit(userName)
    
    else:
      receipt(userName)
      print("Thank you for using the ATM system, goodbye!")    
      return

while True:
  userName = input("\nWelcome, please enter your username: ")
  userName = userName.lower()
  if userName == "exit":
    print("Thank you for using the ATM system, goodbye!")
    break
  n = 3
  exitFlag = False
  validated = False
  while n > 0:
    password = input("hello {}, please input your password. You have {} attempt(s) remaining: ".format(userName, n))
    userName = userName.lower()
    if password == 'exit':
      print("Thank you for using the ATM system, goodbye!")
      exitFlag = True
      break
    elif password != passwordDict[userName]:
      n -= 1
    else:
      validated = True
      break
  
  if exitFlag:
    break
  if validated:
    main_menu(userName)